<?php

return [
    'interfaces' => [
        'google.container.v1.ClusterManager' => [
        ],
    ],
];
