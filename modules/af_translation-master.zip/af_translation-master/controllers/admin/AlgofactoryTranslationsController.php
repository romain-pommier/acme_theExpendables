<?php
/**
 * Created by PhpStorm.
 * User: algo-factory
 * Date: 30/01/19
 * Time: 10:40
 */
require_once(_PS_MODULE_DIR_.'algofactorytranslations'.DIRECTORY_SEPARATOR.'libs/autoload.php');



class AlgofactoryTranslationsController extends ModuleAdminController{

	/**
	 * AlgofactoryTranslationsController constructor.
	 */
    public function __construct()
    {
        parent::__construct();
    }

	/**
	 * @return void
	 */
    public function initContent()
	{
        parent::initContent();

        $this->display_header = false;
		$this->display_header_javascript = false;
		$this->display_footer = false;
		if (Tools::getValue('stringtotranslate')){
			$this->translateOneText();
		}
		else{
			$this->translateAllText();

		}


	}


	public function translateOneText(){
		$text = Tools::getValue('stringtotranslate');
		$googleApiKey = Configuration::get('algofactorytranslations');
		$targetLanguage = Tools::getValue('lang');
		$translate = new Google\Cloud\Translate\TranslateClient();
		$result = $translate->translate($text, [
			'target' => $targetLanguage,
			'key' => $googleApiKey,

		]);
		$jsonresult =  json_encode($result);

		echo $jsonresult;
		die;
	}

	public function translateAllText(){
		$text = $_GET['tab'];
		$googleApiKey = Configuration::get('algofactorytranslations');
		$targetLanguage = Tools::getValue('lang');
		$options = [
			'key' => $googleApiKey,
			'target' => $targetLanguage,
		];
		$translate = new TranslateClient();
		$results = $translate->translateBatch($text,$options);
		foreach ($results as $result) {
			$arrayResults [] =  $result['text'];
		}
		$jsonresult =  json_encode($arrayResults);

		echo $jsonresult;
		die;


	}
}
