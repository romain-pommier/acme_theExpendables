*****
Instalation 
===
Zipper le projet af_translations , puis se rendre dans le back-office de prestashop.
Ajouter le module puis l'installer.

AJOUT API KEY GOOGLE TRANSLATE
===
Se rendre sur https://console.cloud.google.com, ensuite configurer le module et rentrer votre API KEY puis sauvegarder.

POUR LES TRADUCTIONS
==
Se rendre dans back-office de Prestashop , cliquez sur "Localisation" puis sur "Traductions".
Sélectionnez votre type de traduction / votre theme et votre langue puis cliquez sur "Modifiez".
Vos boutons de traductions sont désormais disponibles dans la vue.



DERNIERE MODIF A EFFECTUER 
=====
Faire en sorte de pouvoir récupérer l'API Key DE GOOGLE dans le template twig de l'overide view de prestashop 1.7 !!!!

