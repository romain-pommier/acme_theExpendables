<?php

if (!defined('_PS_VERSION_'))
	exit;
class algofactorytranslations extends Module {

	public function __construct()
	{
		$this->name = 'algofactorytranslations';
		$this->tab = 'back_office_features';
		$this->version = '1.0.0';
		$this->author = 'Algo-Factory';
		$this->need_instance = 0;
		$this->bootstrap = true;
		parent::__construct();
		$this->displayName = $this->l('AlgoFactory translations');
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.7.99.99');
	}

	/**
	 * @return bool
	 */
	public function install()
	{
		if (parent::install() == false || !$this->installTab()) {

			if (!is_dir(_PS_OVERRIDE_DIR_.'controllers/admin/templates/translations/helpers/view/') && '_PS_VERSION_' <1.7){
				mkdir(_PS_OVERRIDE_DIR_.'controllers/admin/templates/translations/helpers/view/',0777,true);
			}
			if('_PS_VERSION_' <1.7){
			copy(__DIR__.'/override/controllers/admin/templates/translations/helpers/view/translation_form.tpl',_PS_OVERRIDE_DIR_.'controllers/admin/templates/translations/helpers/view/translation_form.tpl');
			return false;
			}
		}
		return true;
	}

	/**
	 * @return bool
	 */
    public function uninstallTab()
    {
        $id_tab = (int)Tab::getIdFromClassName('AlgofactoryTranslations');
        if ($id_tab) {
            $tab = new Tab($id_tab);
            return $tab->delete();
        } else
            return false;
    }

	/**
	 * @return void
	 */
    public function installTab()
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->name = array();
        $tab->class_name = 'AlgofactoryTranslations';

        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'Traductions';
        }
        $tab->id_parent = 10;
        $tab->module = 'algofactorytranslations';
        $tab->add();
    }

	/**
	 * @return bool
	 */
	public function uninstall()
	{
		return
			parent::uninstall() &&
            $this->uninstallTab() &&
			Configuration::deleteByName($this->name) &&
			$this->deleteDir();
	}

	/**
	 * @param $params
	 */
	public function hookDisplayHeader($params)
	{
		$this->context->controller->registerJavascript($this->_path.'js/translate.js');
//		$this->registerJavascript('modules-algofactorytranslations','modules/'.$this->name.'/js/translate.js', array('server' => 'remote','position' => 'top' ,'priority' => 0) // Arguments
//		);
	}

	/**
	 * @return string
	 */
	public function getContent()
	{
		$output = null;

		if (Tools::isSubmit('submit'.$this->name))
		{
			$my_module_name = strval(Tools::getValue('algofactorytranslations'));
			if (!$my_module_name
			    || empty($my_module_name)
			    || !Validate::isGenericName($my_module_name))
				$output .= $this->displayError($this->l('Invalid Configuration value'));
			else
			{
				Configuration::updateValue('algofactorytranslations', $my_module_name);
				$output .= $this->displayConfirmation($this->l('Settings updated'));
			}
		}
		return $output.$this->displayForm();
	}

	/**
	 * @return mixed
	 */
	public function displayForm(){

		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

		$fields_form[0]['form'] = array(
			'legend' => array(
				'title' => $this->l('Settings'),
			),
			'input' => array(
				array(
					'type' => 'text',
					'label' => $this->l('Google Translate API KEY'),
					'name' => 'algofactorytranslations',
					'size' => 50,
					'required' => true
				),
			),
			'submit' => array(
				'title' => $this->l('Save'),
				'class' => 'btn btn-default pull-right'
			),
		);
		$helper = new HelperForm();
		$helper->module = $this;
		$helper->name_controller = $this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
		$helper->title = $this->displayName;
		$helper->show_toolbar = true;        // false -> remove toolbar
		$helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
		$helper->submit_action = 'submit'.$this->name;
		$helper->toolbar_btn = array(
			'save' =>
				array(
					'desc' => $this->l('Save'),
					'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
					          '&token='.Tools::getAdminTokenLite('AdminModules'),
				),
			'back' => array(
				'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
				'desc' => $this->l('Back to list')
			)
		);
		$helper->fields_value['algofactorytranslations'] = Configuration::get('algofactorytranslations');
		return $helper->generateForm($fields_form);

	}

	/**
	 * @return void
	 */
	public function deleteDir(){
		@unlink(_PS_OVERRIDE_DIR_.'controllers/admin/templates/translations/helpers/view/af_translation_form.tpl');


	}
}
